﻿# Recipe X
If you enjoy pressing the 'Craft' button over and over and over... This mod is _not_ for you.

## Installation (manual)
1. Copy and paste the RecipeX.dll file into your BepInEx/plugins folder.
2. Run the game. A file will be gererated in the BepInEx/config folder with the name thedefside.RecipeX.json
3. Exit the game. Edit the json file by setting Enabled = true and setting the multiplier > 1 for any recipe you want to use.

## Features
 - Allows you to add new recipes to the game that are multiples of the original recipe
 - Each recipe can have it's own multiplier
 - Recipes can be enabled/disabled through the config
 - generates a file with all the vanilla recipes on first run

## Changelog
v0.0.1
 - Initial version

## Known issues
Only works with vanilla recipes.


You can find the github at: https://github.com/thedefside/valheim-mods/tree/master/RecipeX

[![Arrows](https://i.imgur.com/92cbGVc.png)
![Food](https://i.imgur.com/nVxVrbP.png)]
